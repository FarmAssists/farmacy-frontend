export const TITLE_BG = 'linear-gradient(180deg, #7645D9 0%, #452A7A 100%)'
export const GET_TICKETS_BG = 'linear-gradient(180deg, #7645D9 0%, #5121B1 100%)'
export const FINISHED_ROUNDS_BG = 'linear-gradient(180deg, #CBD7EF 0%, #9A9FD0 100%)'
export const FINISHED_ROUNDS_BG_DARK = 'linear-gradient(180deg, #434575 0%, #66578D 100%)'
